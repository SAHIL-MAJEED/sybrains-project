// Toggle Light/Dark mode
document.getElementById('themeToggle').addEventListener('click', function() {
    document.body.classList.toggle('dark-mode');
});

// Function to render the chart using Chart.js
function renderChart() {
    var ctx = document.getElementById('myChart').getContext('2d');
    var chart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ['January', 'February', 'March'],
            datasets: [{
                label: 'Monthly Sales',
                data: [10, 20, 30],
                backgroundColor: ['#ff6384', '#36a2eb', '#ffce56']
            }]
        }
    });
}

// Function to run Python code using Skulpt
function runPythonCode() {
    let code = document.getElementById('pythonCode').value; // Get code from the textarea
    Sk.misceval.asyncToPromise(function() {
        return Sk.importMainWithBody("<stdin>", false, code, true);
    }).then(function(mod) {
        document.getElementById('pythonOutput').innerText = mod.$d; // Show output
    }).catch(function(err) {
        document.getElementById('pythonOutput').innerText = err.toString(); // Show errors
    });
}

// Call renderChart when the page loads
window.onload = function() {
    renderChart();
};
